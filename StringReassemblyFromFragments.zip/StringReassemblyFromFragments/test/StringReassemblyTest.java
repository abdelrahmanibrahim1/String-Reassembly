import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

public class StringReassemblyTest {

    /*
     * Tests for combination method
     */
    @Test
    public void testCombination_a_b_0() {
        String str1 = "a";
        String expectedStr1 = "a";
        String str2 = "b";
        String expectedStr2 = "b";
        int overlap = 0;
        int expectedOverlap = 0;
        String combinedString = StringReassembly.combination(str1, str2,
                overlap);
        String expectedCombinedString = "ab";
        assertEquals(combinedString, expectedCombinedString);
        assertEquals(str1, expectedStr1);
        assertEquals(str2, expectedStr2);
        assertEquals(overlap, expectedOverlap);
    }

    @Test
    public void testCombination_abcd_cdap_2() {
        String str1 = "abcd";
        String expectedStr1 = "abcd";
        String str2 = "cdap";
        String expectedStr2 = "cdap";
        int overlap = 2;
        int expectedOverlap = 2;
        String combinedString = StringReassembly.combination(str1, str2,
                overlap);
        String expectedCombinedString = "abcdap";
        assertEquals(combinedString, expectedCombinedString);
        assertEquals(str1, expectedStr1);
        assertEquals(str2, expectedStr2);
        assertEquals(overlap, expectedOverlap);
    }

    @Test
    public void testCombination_abcde_cdeap_3() {
        String str1 = "abcde";
        String expectedStr1 = "abcde";
        String str2 = "cdeap";
        String expectedStr2 = "cdeap";
        int overlap = 3;
        int expectedOverlap = 3;
        String combinedString = StringReassembly.combination(str1, str2,
                overlap);
        String expectedCombinedString = "abcdeap";
        assertEquals(combinedString, expectedCombinedString);
        assertEquals(str1, expectedStr1);
        assertEquals(str2, expectedStr2);
        assertEquals(overlap, expectedOverlap);
    }

    /*
     * Tests for addToSetAvoidingSubstrings method
     */

    @Test
    public void testAddToSetAvoidingSubstrings_strIsSubstring() {
        Set<String> setStr = new Set1L<>();
        setStr.add("abcde");
        Set<String> expectedSetStr = new Set1L<>();
        expectedSetStr.add("abcde");
        String str1 = "abc";
        String expectedStr1 = "abc";
        StringReassembly.addToSetAvoidingSubstrings(setStr, str1);
        assertEquals(expectedSetStr, setStr);
        assertEquals(expectedStr1, str1);
    }

    @Test
    public void testAddToSetAvoidingSubstrings_strIsNotSubstringAndSetDoesNotContainSubstring() {
        Set<String> setStr = new Set1L<>();
        setStr.add("ab");
        setStr.add("cd");
        Set<String> expectedSetStr = new Set1L<>();
        expectedSetStr.add("ab");
        expectedSetStr.add("cd");
        expectedSetStr.add("ef");
        String str1 = "ef";
        String expectedStr1 = "ef";
        StringReassembly.addToSetAvoidingSubstrings(setStr, str1);
        assertEquals(expectedSetStr, setStr);
        assertEquals(expectedStr1, str1);
    }

    @Test
    public void testAddToSetAvoidingSubstrings_strIsNotSubstringAndSetContainsSubstring() {
        Set<String> setStr = new Set1L<>();
        setStr.add("ab");
        setStr.add("ef");
        Set<String> expectedSetStr = new Set1L<>();
        expectedSetStr.add("ab");
        expectedSetStr.add("efg");
        String str1 = "efg";
        String expectedStr1 = "efg";
        StringReassembly.addToSetAvoidingSubstrings(setStr, str1);
        assertEquals(expectedSetStr, setStr);
        assertEquals(expectedStr1, str1);
    }

    /*
     * Tests for linesFromInput method
     */

    @Test
    public void testLinesFromInput_emptyFile() {
        SimpleReader input = new SimpleReader1L("Emptyfile.txt");
        Set<String> inputtedLines = new Set1L<>();
        inputtedLines = StringReassembly.linesFromInput(input);
        Set<String> expectedInputtedLines = new Set1L();
        assertEquals(expectedInputtedLines, inputtedLines);
        input.close();
    }

    @Test
    public void testLinesFromInput_buckeyeCheer() {
        SimpleReader input = new SimpleReader1L("cheer-8-2.txt");
        Set<String> inputtedLines = new Set1L<>();
        inputtedLines = StringReassembly.linesFromInput(input);
        Set<String> expectedInputtedLines = new Set1L();
        expectedInputtedLines.add("Bucks -- Beat");
        expectedInputtedLines.add("Go Bucks");
        expectedInputtedLines.add("o Bucks -- B");
        expectedInputtedLines.add("Beat Mich");
        expectedInputtedLines.add("Michigan~");
        assertEquals(expectedInputtedLines, inputtedLines);
        input.close();
    }
    /*
     * Tests for printWithLineSeparators
     */

    @Test
    public void testPrintWithLineSeparators_noSpecialSymbol() {
        SimpleWriter out = new SimpleWriter1L("testFile");
        SimpleReader in = new SimpleReader1L("testFile");
        String testString = "ao";
        StringReassembly.printWithLineSeparators(testString, out);
        Set<String> testFileLines = StringReassembly.linesFromInput(in);
        Set<String> expectedTestFileLines = testFileLines.newInstance();
        expectedTestFileLines.add("ao");
        assertEquals(expectedTestFileLines, testFileLines);
    }

    @Test
    public void testPrintWithLineSeparators_containsSpecialSymbol() {
        SimpleWriter out = new SimpleWriter1L("testFile1");
        SimpleReader in = new SimpleReader1L("testFile1");
        String testString = "a~o";
        StringReassembly.printWithLineSeparators(testString, out);
        Set<String> testFileLines = StringReassembly.linesFromInput(in);
        Set<String> expectedTestFileLines = testFileLines.newInstance();
        expectedTestFileLines.add("a");
        expectedTestFileLines.add("o");
        assertEquals(expectedTestFileLines, testFileLines);
    }

    @Test
    public void testPrintWithLineSeparators_contains3SpecialSymbols() {
        SimpleWriter out = new SimpleWriter1L("testFile2");
        SimpleReader in = new SimpleReader1L("testFile2");
        String testString = "I~am~a~buckeye";
        StringReassembly.printWithLineSeparators(testString, out);
        Set<String> testFileLines = StringReassembly.linesFromInput(in);
        Set<String> expectedTestFileLines = testFileLines.newInstance();
        expectedTestFileLines.add("I");
        expectedTestFileLines.add("am");
        expectedTestFileLines.add("buckeye");
        assertEquals(expectedTestFileLines, testFileLines);
    }
}
